Need to install the following packages:
supabase@1.148.6
Ok to proceed? (y) 